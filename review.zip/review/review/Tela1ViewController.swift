//
//  Tela1ViewController.swift
//  review
//
//  Created by Usuário Convidado on 26/05/17.
//  Copyright © 2017 Usuário Convidado. All rights reserved.
//

import UIKit

class Tela1ViewController: UIViewController {

    @IBOutlet weak var meuWebView: UIWebView!
    
    let URL_PAGINA = "https://www.vive.com/us"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let URL_OK = URL(string: URL_PAGINA)
        let request = URLRequest(url: URL_OK!)
        meuWebView.loadRequest(request)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func resetarNavegacao(sender:UIStoryboardSegue){
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
